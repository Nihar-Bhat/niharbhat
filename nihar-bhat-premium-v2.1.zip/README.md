# Nihar Bhat — Premium Portfolio v2.1

Luxury agency-style portfolio with:
- scroll reveal animations
- hover motion
- full-screen portfolio lightbox
- keyboard arrows + mobile swipe navigation
- responsive mobile layout
- SEO metadata and Person structured data

Upload `index.html` and the `assets/` folder to the root of your GitHub Pages repository.
