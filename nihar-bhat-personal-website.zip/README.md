# Nihar Bhat — Personal Website

This is a ready-to-publish one-page personal profile for Nihar Bhat.

## Publish free with GitHub Pages

1. Create/sign in to GitHub: https://github.com/
2. Create a new **public** repository named exactly:
   `YOUR-USERNAME.github.io`
3. Upload `index.html` and `profile-card.png` to the repository root.
4. Open **Settings → Pages**.
5. Under the publishing source, select the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish.
7. Your website will be:
   `https://YOUR-USERNAME.github.io/`

Before publishing, replace `YOUR-USERNAME` in the canonical URL inside `index.html` with your actual GitHub username.

## Search visibility

Keep the name **Nihar Bhat**, profession, location and Instagram consistent across your public profiles. A public website helps search engines discover a clear source about you, but indexing is not guaranteed or immediate.
